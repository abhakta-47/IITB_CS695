# Civetweb Contributors

* Alex Kozlov
* bel2125
* Ben M. Ward
* brett
* Bjoern Petri
* Brian Lambert
* Brian Spratke
* cdbishop
* celeron55
* Charles Olivi
* Christian Mauderer
* Christopher Galas
* cjh
* Daniel Oaks
* Daniel Rempel
* Danny Al-Gaaf
* David Arnold
* David Loffredo
* Dialga
* Eric Tsau
* F-Secure Corporation
* Fernando G. Aranda
* Grahack
* grenclave
* hansipie
* HariKamath Kamath
* Jack
* Jacob Skillin
* Jan Willem Janssen
* Jeremy Lin
* Jim Evans
* jmc-
* Jochen Scheib
* Joe Mucchiello
* Joel Gallant
* Johan De Taeye
* Jordan
* Jordan Shelley
* Joshua Boyd
* Joshua D. Boyd
* kalphamon
* Keith Kyzivat
* Kevin Wojniak
* Kimmo Mustonen
* Lawrence
* Li Peng
* Lianghui
* Maarten Fremouw
* makrsmark
* Mark Lakata
* Martin Gaida
* Mateusz Gralka
* Matt Clarkson
* mingodad
* Morgan McGuire
* Neil Jensen
* Nick Hildebrant
* Nigel Stewart
* nihildeb
* No Face Press
* Paul Sokolovsky
* Perttu Ahola
* Philipp Friedenberger
* Philipp Hasper
* Red54
* Richard Screene
* Sage Weil
* Sangwhan Moon
* shantanugadgil
* Scott Nations
* sunfch
* thewaterymoon
* Thomas Davis
* tnoho
* Toni Wilk
* Ulrich Hertlein
* Walt Steverson
* William Greathouse
* Yehuda Sadeh

# Mongoose Contributors
Civetweb is based on the Mongoose code.  The following users contributed to the original Mongoose release between 2010 and 2013.  This list was generated from the Mongoose GIT logs.  It does not contain contributions from the Mongoose mailing list.  There is no record for contributors prior to 2010.

* Sergey Lyubka
* Arnout Vandecappelle (Essensium/Mind)
* Benoît Amiaux
* Cody Hanson
* Colin Leitner
* Daniel Oaks
* Eric Bakan
* Erik Oomen
* Filipp Kovalev
* Ger Hobbelt
* Hendrik Polczynski
* Henrique Mendonça
* Igor Okulist
* Jay
* Joe Mucchiello
* John Safranek
* Joseph Mainwaring
* José Miguel Gonçalves
* KIU Shueng Chuan
* Katerina Blinova
* Konstantin Sorokin
* Marin Atanasov Nikolov
* Matt Healy
* Miguel Morales
* Mikhail Nikalyukin
* MikieMorales
* Mitch Hendrickson
* Nigel Stewart
* Pavel
* Pavel Khlebovich
* Rogerz Zhang
* Sebastian Reinhard
* Stefan Doehla
* Thileepan
* abadc0de
* arvidn
* bick
* ff.feng
* jmucchiello
* jwang
* lsm
* migal
* mlamb
* nullable.type
* shantanugadgil
* tayS
* test
* valenok
